<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Jens Hyllegaard <jens.hyllegaard@gmail.com>
 */
$lang['checkupdate']           = 'Søg periodisk efter opdateringer.';
