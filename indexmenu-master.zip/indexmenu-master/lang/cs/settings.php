<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Vojta Olsan <olsh0@seznam.cz>
 */
$lang['checkupdate']           = 'Pravidelně kontrolovat aktualizace';
