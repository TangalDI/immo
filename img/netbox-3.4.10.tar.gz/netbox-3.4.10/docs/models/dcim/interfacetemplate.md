# Interface Templates

A template for a network interface that will be created on all instantiations of the parent device type. See the [interface](./interface.md) documentation for more detail.
