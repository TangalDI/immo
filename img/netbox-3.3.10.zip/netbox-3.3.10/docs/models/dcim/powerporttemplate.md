# Power Port Templates

A template for a power port that will be created on all instantiations of the parent device type. See the [power port](./powerport.md) documentation for more detail.
